package com.unisphere.collegeconnect.utils

const val USER_NODE="User"
const val USER_PROFILE_FOLDER="Profile"
const val POST_FOLDER="PostImages"
const val REEL_FOLDER="Reels"
const val POST="Post"
const val REEL="Reel"
const val FOLLOW="FOLLOW"
